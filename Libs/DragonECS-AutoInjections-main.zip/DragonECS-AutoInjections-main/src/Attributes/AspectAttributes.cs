﻿#if DISABLE_DEBUG
#undef DEBUG
#endif
using System;

namespace DCFApixels.DragonECS
{
    public abstract class InjectAspectMemberAttribute : Attribute { }
    [AttributeUsage(AttributeTargets.Field, Inherited = false, AllowMultiple = false)]
    public sealed class IncAttribute : InjectAspectMemberAttribute { }
    [AttributeUsage(AttributeTargets.Field, Inherited = false, AllowMultiple = false)]
    public sealed class ExcAttribute : InjectAspectMemberAttribute { }
    [AttributeUsage(AttributeTargets.Field, Inherited = false, AllowMultiple = false)]
    public sealed class OptAttribute : InjectAspectMemberAttribute { }
    [AttributeUsage(AttributeTargets.Field, Inherited = false, AllowMultiple = false)]
    public sealed class CombineAttribute : InjectAspectMemberAttribute
    {
        public readonly int Order = 0;
        public CombineAttribute(int order = 0) { Order = order; }
    }
    [AttributeUsage(AttributeTargets.Field, Inherited = false, AllowMultiple = false)]
    public sealed class MaskAttribute : InjectAspectMemberAttribute { }


    public abstract class ImplicitInjectAttribute : Attribute
    {
        public readonly Type ComponentType;
        public ImplicitInjectAttribute(Type componentType)
        {
            ComponentType = componentType;
        }
    }
    [AttributeUsage(AttributeTargets.Field | AttributeTargets.Class, Inherited = false, AllowMultiple = true)]
    public sealed class IncImplicitAttribute : ImplicitInjectAttribute
    {
        public IncImplicitAttribute(Type type) : base(type) { }
    }
    [AttributeUsage(AttributeTargets.Field | AttributeTargets.Class, Inherited = false, AllowMultiple = true)]
    public sealed class ExcImplicitAttribute : ImplicitInjectAttribute
    {
        public ExcImplicitAttribute(Type type) : base(type) { }
    }
}

